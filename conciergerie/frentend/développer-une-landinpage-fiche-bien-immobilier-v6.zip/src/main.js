
import Vue from 'vue';
import App from './App.js';

// In Vue 2, we create a new Vue instance
// and pass the root component to the `render` function.
new Vue({
  el: '#app',
  render: h => h(App)
});
