
import React from 'react';
import './App.css';
import CheckInLanding from './features/checkInLanding/CheckInLanding';

const App = () => (
  <div className="app-shell">
    <CheckInLanding />
  </div>
);

export default App;
