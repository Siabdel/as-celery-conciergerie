
import React from 'react';
import './StatusPill.css';

type StatusPillTone = 'success' | 'warning' | 'danger' | 'info' | 'neutral';

type StatusPillProps = {
  label: string;
  tone?: StatusPillTone;
  icon?: string;
};

const StatusPill: React.FC<StatusPillProps> = ({ label, tone = 'neutral', icon }) => (
  <span className={`status-pill status-pill__${tone}`}>
    {icon && <span className="status-pill__icon" aria-hidden="true">{icon}</span>}
    {label}
  </span>
);

export default StatusPill;
