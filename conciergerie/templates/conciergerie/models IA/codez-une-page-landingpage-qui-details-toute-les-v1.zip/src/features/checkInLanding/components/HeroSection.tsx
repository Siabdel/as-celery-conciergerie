
import React, { useMemo } from 'react';
import './HeroSection.css';
import StatusPill from '../../../components/StatusPill/StatusPill';

type Collaborator = {
  name: string;
  role: string;
};

type HeroSectionProps = {
  propertyName: string;
  location: string;
  referenceCode: string;
  readinessScore: number;
  arrivalCountdown: string;
  checkInWindow: string;
  stayRange: string;
  arrivalFlight: string;
  collaborator: Collaborator;
  clientNames: string[];
};

const HeroSection: React.FC<HeroSectionProps> = ({
  propertyName,
  location,
  referenceCode,
  readinessScore,
  arrivalCountdown,
  checkInWindow,
  stayRange,
  arrivalFlight,
  collaborator,
  clientNames,
}) => {
  const conicValue = useMemo(() => Math.min(360, Math.max(0, readinessScore * 3.6)), [readinessScore]);
  const guestLine = useMemo(() => {
    if (clientNames.length === 0) return '';
    if (clientNames.length === 1) return clientNames[0];
    return `${clientNames.slice(0, -1).join(', ')} & ${clientNames.slice(-1)}`;
  }, [clientNames]);

  return (
    <header className="hero">
      <div className="hero__background" aria-hidden="true">
        <span className="hero__glow hero__glow--primary" />
        <span className="hero__glow hero__glow--secondary" />
        <span className="hero__glow hero__glow--tertiary" />
      </div>
      <div className="hero__content">
        <div className="hero__pills">
          <StatusPill label={referenceCode} tone="info" icon="🗂️" />
          <StatusPill label={`Arrivée ${arrivalCountdown}`} tone="warning" icon="⏱️" />
        </div>
        <div className="hero__heading">
          <h1>{propertyName}</h1>
          <p className="hero__subtitle">
            Check-in invités — {guestLine}. Préparez une arrivée sans friction et une expérience signature
            Riviera, parfaitement orchestrée avant leur arrivée.
          </p>
        </div>
        <div className="hero__meta">
          <div>
            <span className="hero__eyebrow">Emplacement</span>
            <p className="hero__meta-value">{location}</p>
          </div>
          <div>
            <span className="hero__eyebrow">Fenêtre d’accueil</span>
            <p className="hero__meta-value">{checkInWindow}</p>
          </div>
          <div>
            <span className="hero__eyebrow">Durée du séjour</span>
            <p className="hero__meta-value">{stayRange}</p>
          </div>
          <div>
            <span className="hero__eyebrow">Vol & arrivée</span>
            <p className="hero__meta-value">{arrivalFlight}</p>
          </div>
        </div>
        <div className="hero__cta">
          <button className="hero__cta-btn hero__cta-btn--primary" type="button">
            Lancer le brief d’équipe
          </button>
          <button className="hero__cta-btn hero__cta-btn--ghost" type="button">
            Exporter la feuille de route
          </button>
        </div>
      </div>
      <aside className="hero__readiness">
        <div
          className="hero__readiness-gauge"
          style={{
            background: `conic-gradient(var(--color-secondary) ${conicValue}deg, rgba(148, 163, 184, 0.15) ${conicValue}deg)`,
          }}
        >
          <div className="hero__readiness-inner">
            <span className="hero__readiness-value">{readinessScore}%</span>
            <span className="hero__readiness-label">Prêt</span>
          </div>
        </div>
        <div className="hero__readiness-details">
          <p className="hero__readiness-title">Plan d’accueil orchestré</p>
          <p className="hero__readiness-description">
            {collaborator.name} ({collaborator.role}) pilote ce check-in. Vérifiez les services à 8 heures du
            départ pour atteindre 100%.
          </p>
        </div>
      </aside>
    </header>
  );
};

export default HeroSection;
