
import React from 'react';
import './ScheduleSection.css';
import StatusPill from '../../../components/StatusPill/StatusPill';

type Schedule = {
  arrivalDate: string;
  arrivalTime: string;
  preInspection: string;
  housekeeping: string;
  welcomeCall: string;
  transportation: string;
  keyExchange: string;
  propertyAccess: string;
  departureDate: string;
};

type ScheduleSectionProps = {
  schedule: Schedule;
  referenceCode: string;
};

const ScheduleSection: React.FC<ScheduleSectionProps> = ({ schedule, referenceCode }) => {
  const timeline = [
    {
      label: 'Pré-inspection & sécurité',
      detail: schedule.preInspection,
      icon: '🛠️',
    },
    {
      label: 'Ménage prestige',
      detail: schedule.housekeeping,
      icon: '🧼',
    },
    {
      label: 'Brief digital invité',
      detail: schedule.welcomeCall,
      icon: '📞',
    },
    {
      label: 'Coordination chauffeur',
      detail: schedule.transportation,
      icon: '🚘',
    },
    {
      label: 'Remise des accès',
      detail: schedule.keyExchange,
      icon: '🔑',
    },
    {
      label: 'Digicode & domotique',
      detail: schedule.propertyAccess,
      icon: '🏡',
    },
    {
      label: 'Départ & closing',
      detail: schedule.departureDate,
      icon: '🧳',
    },
  ];

  return (
    <section className="schedule">
      <header className="schedule__header">
        <div>
          <h2>Dates & jalons critiques</h2>
          <p>
            Visualisez les étapes clés du dossier {referenceCode}. Synchronisez équipes terrain et partenaires
            externes.
          </p>
        </div>
        <StatusPill label="Plan validé" tone="success" icon="📅" />
      </header>
      <div className="schedule__main">
        <div className="schedule__arrival">
          <p className="schedule__arrival-label">Arrivée confirmée</p>
          <p className="schedule__arrival-date">{schedule.arrivalDate}</p>
          <p className="schedule__arrival-time">{schedule.arrivalTime}</p>
        </div>
        <ul className="schedule__timeline">
          {timeline.map((entry) => (
            <li className="schedule__item" key={entry.label}>
              <span className="schedule__icon" aria-hidden="true">
                {entry.icon}
              </span>
              <div>
                <p className="schedule__item-label">{entry.label}</p>
                <p className="schedule__item-detail">{entry.detail}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
};

export default ScheduleSection;
