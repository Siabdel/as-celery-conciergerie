
import React from 'react';
import './RequestsSection.css';
import StatusPill from '../../../components/StatusPill/StatusPill';

type Request = {
  title: string;
  description: string;
  priority: string;
  status: string;
  owner: string;
  tags?: string[];
  due: string;
};

type RequestsSectionProps = {
  requests: Request[];
};

const RequestsSection: React.FC<RequestsSectionProps> = ({ requests }) => (
  <section className="requests">
    <header className="requests__header">
      <div>
        <h2>Demandes supplémentaires</h2>
        <p>Personnalisez l’accueil selon les souhaits des invités. Coordination en temps réel avec partenaires.</p>
      </div>
      <StatusPill label="Expérience sur-mesure" tone="info" icon="🎯" />
    </header>
    <div className="requests__list">
      {requests.map((request) => (
        <article className="request-card" key={request.title}>
          <div className="request-card__head">
            <h3>{request.title}</h3>
            <div className="request-card__status">
              <StatusPill label={request.priority} tone={request.priority === 'Haute' ? 'warning' : 'neutral'} icon="⭐" />
              <StatusPill
                label={request.status}
                tone={request.status === 'Confirmé' ? 'success' : request.status === 'En cours' ? 'info' : 'warning'}
                icon="📌"
              />
            </div>
          </div>
          <p className="request-card__description">{request.description}</p>
          <div className="request-card__footer">
            <div>
              <span className="request-card__label">Responsable</span>
              <p>{request.owner}</p>
            </div>
            <div>
              <span className="request-card__label">Échéance</span>
              <p>{request.due}</p>
            </div>
          </div>
          {request.tags && (
            <div className="request-card__tags">
              {request.tags.map((tag) => (
                <span className="request-card__tag" key={tag}>
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </article>
      ))}
    </div>
  </section>
);

export default RequestsSection;
