
import React from 'react';
import './ClientsPanel.css';
import StatusPill from '../../../components/StatusPill/StatusPill';

type Client = {
  name: string;
  identifier: string;
  email: string;
  phone: string;
  note?: string;
  tags?: string[];
  nationality?: string;
  documentStatus?: string;
  arrivalEta?: string;
  color?: string;
};

type ClientsPanelProps = {
  clients: Client[];
};

const ClientsPanel: React.FC<ClientsPanelProps> = ({ clients }) => (
  <section className="clients">
    <header className="clients__header">
      <div>
        <h2>Invités & Identifications</h2>
        <p>Documents vérifiés, coordonnées, préférences et détails personnalisés.</p>
      </div>
      <StatusPill label="Identité validée" tone="success" icon="🔐" />
    </header>
    <div className="clients__list">
      {clients.map((client) => (
        <article className="client-card" key={client.identifier}>
          <span
            className="client-card__avatar"
            style={{ background: client.color ?? 'rgba(99, 102, 241, 0.6)' }}
            aria-hidden="true"
          >
            {client.name.slice(0, 1)}
          </span>
          <div className="client-card__body">
            <div className="client-card__top">
              <div>
                <h3>{client.name}</h3>
                <p className="client-card__identifier">{client.identifier}</p>
              </div>
              <StatusPill
                label={client.documentStatus ?? 'À vérifier'}
                tone={client.documentStatus === 'Validé' ? 'success' : 'warning'}
                icon="🪪"
              />
            </div>
            <div className="client-card__details">
              <div>
                <span className="client-card__label">Contact</span>
                <p>{client.phone}</p>
                <p>{client.email}</p>
              </div>
              <div>
                <span className="client-card__label">Nationalité</span>
                <p>{client.nationality}</p>
                <span className="client-card__label">ETA</span>
                <p>{client.arrivalEta}</p>
              </div>
            </div>
            {client.tags && (
              <div className="client-card__tags">
                {client.tags.map((tag) => (
                  <span className="client-card__tag" key={tag}>
                    {tag}
                  </span>
                ))}
              </div>
            )}
            {client.note && <p className="client-card__note">{client.note}</p>}
          </div>
        </article>
      ))}
    </div>
  </section>
);

export default ClientsPanel;
