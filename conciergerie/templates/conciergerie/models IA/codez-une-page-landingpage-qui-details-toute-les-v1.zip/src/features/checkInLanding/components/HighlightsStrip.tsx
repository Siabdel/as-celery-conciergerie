
import React from 'react';
import './HighlightsStrip.css';

type Metric = {
  title: string;
  value: string;
  caption: string;
  icon?: string;
};

type HighlightsStripProps = {
  metrics: Metric[];
};

const HighlightsStrip: React.FC<HighlightsStripProps> = ({ metrics }) => (
  <section className="highlights">
    {metrics.map((metric) => (
      <article className="highlight-card" key={metric.title}>
        <div className="highlight-card__icon" aria-hidden="true">
          {metric.icon ?? '📌'}
        </div>
        <div className="highlight-card__content">
          <h3>{metric.value}</h3>
            <p className="highlight-card__title">{metric.title}</p>
          <p className="highlight-card__caption">{metric.caption}</p>
        </div>
      </article>
    ))}
  </section>
);

export default HighlightsStrip;
