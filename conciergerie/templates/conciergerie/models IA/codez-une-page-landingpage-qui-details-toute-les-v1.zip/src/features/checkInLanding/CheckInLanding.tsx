
import React from 'react';
import './CheckInLanding.css';
import HeroSection from './components/HeroSection';
import HighlightsStrip from './components/HighlightsStrip';
import ClientsPanel from './components/ClientsPanel';
import ScheduleSection from './components/ScheduleSection';
import ServicesSection from './components/ServicesSection';
import RequestsSection from './components/RequestsSection';
import CollaboratorSection from './components/CollaboratorSection';
import FooterCTA from './components/FooterCTA';

const checkInData = {
  propertyName: 'Résidence Riviera · Penthouse 12B',
  location: 'Promenade des Anglais, Nice',
  referenceCode: 'CHK-2024-0718',
  arrivalCountdown: 'J-3',
  readinessScore: 92,
  checkInWindow: 'Jeudi 18 juillet 2024 · 14h30 — 15h30',
  stayRange: '18 → 21 juillet 2024',
  arrivalFlight: 'Air France AF1683 · Arrivée 13h10 (NCE)',
  collaborator: {
    name: 'Soline Dupuis',
    role: 'Guest Experience Manager',
    phone: '+33 6 78 12 45 09',
    email: 'soline.dupuis@hubconciergeriviera.fr',
    timezone: 'UTC+1 · CET',
    languages: ['Français', 'Anglais', 'Italien'],
    availability: '08h00 — 22h00',
    signature: '« L’excellence d’un accueil commence bien avant la poignée de main. »',
    avatarColor: '#6366f1',
  },
  clients: [
    {
      name: 'Lucas Moreau',
      identifier: 'CLI-4821',
      email: 'lucas.moreau@email.fr',
      phone: '+33 6 14 28 94 77',
      note: 'Allergique aux fruits à coque · Voyage de noces',
      tags: ['Lead invité', 'Premium'],
      nationality: '🇫🇷 France',
      documentStatus: 'Validé',
      arrivalEta: '14h30',
      color: '#6366f1',
    },
    {
      name: 'Amélie Garnier',
      identifier: 'CLI-4822',
      email: 'amelie.garnier@email.fr',
      phone: '+33 6 52 88 21 45',
      note: 'Oreillers mémoire de forme · Massage samedi 10h',
      tags: ['Co-invitée', 'Bien-être'],
      nationality: '🇫🇷 France',
      documentStatus: 'Validé',
      arrivalEta: '14h30',
      color: '#f472b6',
    },
  ],
  schedule: {
    arrivalDate: 'Jeudi 18 juillet 2024',
    arrivalTime: '14h30',
    preInspection: 'Mardi 16 juillet · 10h00',
    housekeeping: 'Mercredi 17 juillet · 14h00',
    welcomeCall: 'Mercredi 17 juillet · 18h00 (Zoom)',
    transportation: 'Chauffeur privé — Riviera Drives · Confirmé 13h15',
    keyExchange: 'Conciergerie Riviera · 13h45',
    propertyAccess: 'Digicode 1289A · Badges dans coffret connecté',
    departureDate: 'Dimanche 21 juillet 2024 · 11h00',
  },
  services: [
    {
      title: 'Inspection technique & checklist 52 points',
      status: 'done' as const,
      owner: 'Soline Dupuis',
      due: '48h avant arrivée',
      impact: 'Sécurité & confort',
      notes: 'Valider mini-bar, prises USB, profils Sonos, bougies recharge.',
    },
    {
      title: 'Coordination ménage prestige + blanchisserie',
      status: 'in-progress' as const,
      owner: 'Prestige Clean Partners',
      due: '36h avant arrivée',
      impact: 'Propreté signature',
      progress: 70,
      notes: 'Inclure linge satiné + surmatelas nuage.',
    },
    {
      title: 'Livraison FreshBox · Frigo rempli & épicerie locale',
      status: 'pending' as const,
      owner: 'Partenaire FreshBox',
      due: '24h avant arrivée',
      impact: 'Expérience culinaire',
      notes: 'Charte : produits bio & champagne rosé déjà commandé.',
    },
    {
      title: 'Mise en scène romantique & ambiance lumineuse',
      status: 'scheduled' as const,
      owner: 'Atelier Floral Marceau',
      due: 'Jour J · 12h00',
      impact: 'Effet wahou à l’ouverture de porte',
      notes: 'Plafonnier dimmé, chemin de pétales, playlist « Riviera Sunset ».',
    },
    {
      title: 'Brief chauffeur & synchronisation arrivée',
      status: 'in-progress' as const,
      owner: 'Riviera Drives',
      due: 'Jour J · 11h30',
      impact: 'Fluidité check-in',
      progress: 45,
      notes: 'Partager numéro de vol mis à jour + contact Soline.',
    },
  ],
  requests: [
    {
      title: 'Setup romantique & champagne millésimé',
      description:
        'Prévoir bouquet de pivoines cascade, sceau à champagne Moët Grand Vintage 2015 et playlist lounge sur Sonos terrasse.',
      priority: 'Haute',
      status: 'Confirmé',
      owner: 'Atelier Floral Marceau',
      tags: ['Ambiance', 'VIP'],
      due: 'Jour J · 13h00',
    },
    {
      title: 'Réservation massage duo · Spa des Artistes',
      description:
        'Massage signature en cabine duo le samedi 20 juillet à 10h00. Vérifier intolérances huiles essentielles.',
      priority: 'Normale',
      status: 'En attente paiement',
      owner: 'Spa des Artistes',
      tags: ['Bien-être', 'Coordination'],
      due: 'Avant 17 juillet · 12h',
    },
    {
      title: 'Itinéraire gastronomie · recommandations locales',
      description:
        'Préparer conciergerie-booklet avec 3 tables gastronomiques + plan dégustation rosé à Cap Ferrat.',
      priority: 'Normale',
      status: 'En cours',
      owner: 'Soline Dupuis',
      tags: ['Guest Care', 'Edition'],
      due: '48h avant arrivée',
    },
  ],
  comms: {
    slackChannel: '#checkin-riviera',
    lastUpdate: '15 juillet 2024 · 09h40',
    summary:
      'Soline a confirmé la livraison FreshBox. Chauffeur en attente du numéro de vol actualisé (Air France communiqué d’ici 16h).',
    escalation: 'Alerter Marion (Ops Lead) si arrivée décalée de +45 minutes.',
  },
  propertyManager: {
    name: 'Hub Concierge Riviera',
    phone: '+33 4 93 00 12 34',
    email: 'operations@hubconciergeriviera.fr',
    ctaLabel: 'Planifier le point final',
    secondaryCtaLabel: 'Exporter le dossier check-in',
  },
  metrics: [
    {
      title: 'Clients confirmés',
      value: '2',
      caption: 'Identité vérifiée & contrats signés',
      icon: '👥',
    },
    {
      title: 'Services pré-arrivée',
      value: '5',
      caption: '3 réalisés · 2 en cours',
      icon: '🛎️',
    },
    {
      title: 'Score de préparation',
      value: '92%',
      caption: 'Objectif qualité 95% d’ici J-1',
      icon: '✨',
    },
    {
      title: 'Réactivité communication',
      value: '14 min',
      caption: 'Temps moyen de réponse Slack',
      icon: '💬',
    },
  ],
};

const CheckInLanding: React.FC = () => {
  const clientNames = checkInData.clients.map((client) => client.name);

  return (
    <div className="checkin-landing">
      <HeroSection
        propertyName={checkInData.propertyName}
        location={checkInData.location}
        referenceCode={checkInData.referenceCode}
        readinessScore={checkInData.readinessScore}
        arrivalCountdown={checkInData.arrivalCountdown}
        checkInWindow={checkInData.checkInWindow}
        stayRange={checkInData.stayRange}
        arrivalFlight={checkInData.arrivalFlight}
        collaborator={checkInData.collaborator}
        clientNames={clientNames}
      />
      <HighlightsStrip metrics={checkInData.metrics} />
      <main className="checkin-main">
        <div className="checkin-layout">
          <ClientsPanel clients={checkInData.clients} />
          <ScheduleSection schedule={checkInData.schedule} referenceCode={checkInData.referenceCode} />
        </div>
        <ServicesSection services={checkInData.services} />
        <RequestsSection requests={checkInData.requests} />
        <CollaboratorSection collaborator={checkInData.collaborator} comms={checkInData.comms} />
      </main>
      <FooterCTA propertyManager={checkInData.propertyManager} />
    </div>
  );
};

export default CheckInLanding;
