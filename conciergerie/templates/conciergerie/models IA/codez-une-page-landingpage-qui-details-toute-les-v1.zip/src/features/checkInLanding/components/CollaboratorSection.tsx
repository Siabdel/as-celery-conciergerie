
import React from 'react';
import './CollaboratorSection.css';
import StatusPill from '../../../components/StatusPill/StatusPill';

type Collaborator = {
  name: string;
  role: string;
  phone: string;
  email: string;
  timezone: string;
  languages: string[];
  availability: string;
  signature: string;
  avatarColor: string;
};

type Comms = {
  slackChannel: string;
  lastUpdate: string;
  summary: string;
  escalation: string;
};

type CollaboratorSectionProps = {
  collaborator: Collaborator;
  comms: Comms;
};

const CollaboratorSection: React.FC<CollaboratorSectionProps> = ({ collaborator, comms }) => (
  <section className="collaborator">
    <div className="collaborator__profile">
      <div className="collaborator__identity">
        <span className="collaborator__avatar" style={{ background: collaborator.avatarColor }}>
          {collaborator.name
            .split(' ')
            .map((segment) => segment[0])
            .join('')}
        </span>
        <div>
          <h2>{collaborator.name}</h2>
          <p>{collaborator.role}</p>
        </div>
      </div>
      <div className="collaborator__grid">
        <div>
          <span className="collaborator__label">Contact direct</span>
          <p>{collaborator.phone}</p>
          <p>{collaborator.email}</p>
        </div>
        <div>
          <span className="collaborator__label">Fuseau & disponibilité</span>
          <p>{collaborator.timezone}</p>
          <p>{collaborator.availability}</p>
        </div>
        <div>
          <span className="collaborator__label">Langues</span>
          <p>{collaborator.languages.join(' · ')}</p>
        </div>
      </div>
      <blockquote className="collaborator__quote">“{collaborator.signature}”</blockquote>
    </div>
    <div className="collaborator__comms">
      <header className="collaborator__comms-header">
        <div>
          <h3>Communication d’équipe</h3>
          <p>Slack & notes opérationnelles en temps réel.</p>
        </div>
        <StatusPill label={comms.slackChannel} tone="info" icon="💬" />
      </header>
      <div className="collaborator__comms-body">
        <div className="collaborator__comms-item">
          <span className="collaborator__label">Dernière mise à jour</span>
          <p>{comms.lastUpdate}</p>
        </div>
        <div className="collaborator__comms-item">
          <span className="collaborator