
import React from 'react';
import './ServicesSection.css';
import StatusPill from '../../../components/StatusPill/StatusPill';

type ServiceStatus = 'done' | 'in-progress' | 'pending' | 'scheduled';

type Service = {
  title: string;
  status: ServiceStatus;
  owner: string;
  due: string;
  impact: string;
  notes?: string;
  progress?: number;
};

type ServicesSectionProps = {
  services: Service[];
};

const statusMap: Record<ServiceStatus, { label: string; tone: 'success' | 'warning' | 'danger' | 'info' | 'neutral'; icon: string }> = {
  done: { label: 'Terminé', tone: 'success', icon: '✅' },
  'in-progress': { label: 'En cours', tone: 'info', icon: '⚙️' },
  pending: { label: 'À lancer', tone: 'warning', icon: '⏳' },
  scheduled: { label: 'Planifié', tone: 'neutral', icon: '🗓️' },
};

const ServicesSection: React.FC<ServicesSectionProps> = ({ services }) => (
  <section className="services">
    <header className="services__header">
      <div>
        <h2>Services pré-arrivée</h2>
        <p>
          Liste exhaustive des actions à finaliser avant l’accueil. Priorisez par impact sur l’expérience
          guest.
        </p>
      </div>
      <StatusPill label="Workflow premium" tone="info" icon="🧭" />
    </header>
    <div className="services__list">
      {services.map((service) => {
        const status = statusMap[service.status];
        return (
          <article className="service-card" key={service.title}>
            <div className="service-card__top">
              <div>
                <h3>{service.title}</h3>
                <p className="service-card__impact">{service.impact}</p>
              </div>
              <StatusPill label={`${status.icon} ${status.label}`} tone={status.tone} />
            </div>
            <div className="service-card__meta">
              <div>
                <span className="service-card__label">Responsable</span>
                <p>{service.owner}</p>
              </div>
              <div>
                <span className="service-card__label">Échéance</span>
                <p>{service.due}</p>
              </div>
            </div>
            {service.progress !== undefined && (
              <div className="service-card__progress">
                <div className="service-card__progress-track">
                  <div
                    className="service-card__progress-value"
                    style={{ width: `${service.progress}%` }}
                    aria-hidden="true"
                  />
                </div>
                <span className="service-card__progress-label">{service.progress}%</span>
              </div>
            )}
            {service.notes && <p className="service-card__notes">{service.notes}</p>}
          </article>
        );
      })}
    </div>
  </section>
);

export default ServicesSection;
