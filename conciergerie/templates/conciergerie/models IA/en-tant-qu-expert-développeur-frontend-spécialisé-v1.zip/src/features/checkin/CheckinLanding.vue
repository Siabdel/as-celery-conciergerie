
<template>
  <!-- Assurez-vous d'inclure Bootstrap 5 et Font Awesome 6 dans le <head> de votre application -->
  <main class="checkin-page bg-body-tertiary">
    <section
      v-if="isLoading"
      class="loading-section d-flex align-items-center justify-content-center text-center"
      aria-live="polite"
    >
      <div>
        <div class="spinner-border text-primary spinner-lg" role="status">
          <span class="visually-hidden">Chargement...</span>
        </div>
        <p class="mt-4 mb-0 fw-semibold text-secondary">
          Nous préparons vos détails de check-in personnalisés…
        </p>
      </div>
    </section>

    <section v-else class="py-5">
      <div class="container">
        <div
          v-if="errorMessage"
          class="alert alert-danger shadow-sm border-0 rounded-4"
          role="alert"
        >
          <i class="fa-solid fa-triangle-exclamation me-2"></i>{{ errorMessage }}
        </div>

        <div v-else-if="checkinData" class="fade-in">
          <header class="mb-5">
            <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-4">
              <div>
                <p class="text-uppercase text-muted fw-semibold mb-2 tracking-wide">
                  Agence Conciergerie Horizon
                </p>
                <h1 class="display-5 fw-bold text-dark mb-3">
                  Détails du Check-in #{{ checkinData.id }}
                </h1>
                <p class="lead text-secondary mb-0">
                  Coordination soignée pour offrir à vos invités un accueil exceptionnel.
                </p>
              </div>
              <span
                :class="['badge', 'status-badge', 'text-bg-' + statusVariant]"
                aria-label="Statut du check-in"
              >
                <i class="fa-solid fa-circle-check me-2"></i>{{ checkinData.status }}
              </span>
            </div>
          </header>

          <section aria-labelledby="collaborator-title" class="mb-5">
            <div class="row g-4">
              <div class="col-12">
                <article class="card border-0 shadow-soft h-100 rounded-4 overflow-hidden">
                  <div class="card-body p-4 p-lg-5 d-flex flex-column flex-md-row align-items-md-center gap-4">
                    <div class="avatar-wrapper flex-shrink-0">
                      <div class="avatar-fallback">
                        <span>{{ collaboratorInitials }}</span>
                      </div>
                    </div>
                    <div class="flex-grow-1">
                      <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                        <div>
                          <h2 id="collaborator-title" class="h4 fw-bold mb-1 text-dark">
                            {{ checkinData.collaborator.name }}
                          </h2>
                          <p class="mb-2 text-secondary">
                            {{ checkinData.collaborator.role }}
                          </p>
                          <div class="d-flex flex-wrap gap-3 text-secondary">
                            <span class="d-flex align-items-center gap-2">
                              <i class="fa-regular fa-envelope text-primary"></i>
                              <a :href="`mailto:${checkinData.collaborator.email}`" class="link-body-emphasis">
                                {{ checkinData.collaborator.email }}
                              </a>
                            </span>
                            <span class="d-flex align-items-center gap-2">
                              <i class="fa-solid fa-phone text-primary"></i>
                              <a :href="`tel:${checkinData.collaborator.phone}`" class="link-body-emphasis">
                                {{ checkinData.collaborator.phone }}
                              </a>
                            </span>
                          </div>
                        </div>
                        <div class="collaborator-pill text-center text-md-end">
                          <p class="fw-semibold text-muted mb-1">Temps fort</p>
                          <p class="mb-0 text-dark">
                            {{ checkinData.collaborator.highlight }}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </article>
              </div>
            </div>
          </section>

          <section class="mb-5">
            <div class="row g-4">
              <div class="col-12 col-lg-6">
                <article class="card border-0 shadow-soft h-100 rounded-4 overflow-hidden">
                  <div class="card-body p-4 p-lg-5">
                    <div class="d-flex align-items-start justify-content-between gap-3 mb-4">
                      <div>
                        <h2 class="card-title h4 fw-bold text-dark mb-1">
                          Détails du Séjour
                        </h2>
                        <p class="text-muted mb-0 small text-uppercase fw-semibold tracking-wide">
                          {{ formattedStayDates }}
                        </p>
                      </div>
                      <span class="badge text-bg-primary-subtle text-primary-emphasis rounded-pill fw-semibold">
                        {{ stayNights }} {{ stayNights > 1 ? 'nuits' : 'nuit' }}
                      </span>
                    </div>

                    <div class="stay-badges d-flex flex-wrap gap-2 mb-4">
                      <span class="badge rounded-pill text-bg-light text-secondary fw-semibold">
                        <i class="fa-solid fa-clock me-2 text-primary"></i>{{ checkinData.stay.arrivalWindow }}
                      </span>
                      <span class="badge rounded-pill text-bg-light text-secondary fw-semibold">
                        <i class="fa-regular fa-calendar-xmark me-2 text-primary"></i>Départ {{ checkinData.stay.departureTime }}
                      </span>
                    </div>

                    <ul class="list-unstyled mb-4 stay-highlights">
                      <li class="d-flex align-items-start gap-3 py-2">
                        <span class="icon-pill bg-primary-subtle text-primary">
                          <i class="fa-solid fa-house-chimney"></i>
                        </span>
                        <div>
                          <p class="fw-semibold mb-1 text-dark">{{ checkinData.stay.propertyName }}</p>
                          <p class="mb-0 text-secondary">{{ checkinData.stay.address }}</p>
                        </div>
                      </li>
                      <li class="d-flex align-items-start gap-3 py-2">
                        <span class="icon-pill bg-info-subtle text-info">
                          <i class="fa-solid fa-wifi"></i>
                        </span>
                        <div>
                          <p class="fw-semibold mb-1 text-dark">Wi-Fi invité</p>
                          <p class="mb-0 text-secondary">
                            <strong>Réseau :</strong> {{ checkinData.stay.wifiNetwork }}
                            <br />
                            <strong>Mot de passe :</strong> {{ checkinData.stay.wifiPassword }}
                          </p>
                        </div>
                      </li>
                      <li class="d-flex align-items-start gap-3 py-2">
                        <span class="icon-pill bg-warning-subtle text-warning">
                          <i class="fa-solid fa-key"></i>
                        </span>
                        <div>
                          <p class="fw-semibold mb-1 text-dark">Remise des clés</p>
                          <p class="mb-0 text-secondary">
                            {{ checkinData.stay.keyInstructions }}
                          </p>
                        </div>
                      </li>
                    </ul>

                    <div class="bg-body-secondary-subtle rounded-4 p-4">
                      <p class="fw-semibold text-dark mb-2">
                        <i class="fa-regular fa-note-sticky me-2 text-primary"></i>Notes concierge
                      </p>
                      <p class="mb-0 text-secondary">
                        {{ checkinData.stay.conciergeNotes }}
                      </p>
                    </div>
                  </div>
                </article>
              </div>

              <div class="col-12 col-lg-6">
                <article class="card border-0 shadow-soft h-100 rounded-4 overflow-hidden">
                  <div class="card-body p-4 p-lg-5">
                    <div class="d-flex align-items-start justify-content-between gap-3 mb-4">
                      <div>
                        <h2 class="card-title h4 fw-bold text-dark mb-1">
                          Informations Client
                        </h2>
                        <p class="text-muted mb-0 small text-uppercase fw-semibold tracking-wide">
                          {{ checkinData.guest.fullName }}
                        </p>
                      </div>
                      <span
                        v-if="checkinData.guest.vip"
                        class="badge text-bg-warning-subtle text-warning-emphasis rounded-pill fw-semibold"
                      >
                        <i class="fa-solid fa-crown me-2"></i>VIP
                      </span>
                    </div>

                    <div class="guest-overview d-flex flex-wrap gap-3 mb-4">
                      <span class="info-chip">
                        <i class="fa-solid fa-user-group me-2 text-primary"></i>
                        {{ checkinData.guest.occupants }} voyageurs
                      </span>
                      <span class="info-chip">
                        <i class="fa-solid fa-plane-arrival me-2 text-primary"></i>
                        {{ checkinData.guest.arrivalDetails }}
                      </span>
                      <span class="info-chip" v-if="checkinData.guest.country">
                        <i class="fa-solid fa-earth-europe me-2 text-primary"></i>
                        {{ checkinData.guest.country }}
                      </span>
                    </div>

                    <ul class="list-unstyled mb-4 guest-contacts">
                      <li class="d-flex align-items-start gap-3 py-2">
                        <span class="icon-pill bg-primary text-white">
                          <i class="fa-solid fa-mobile-screen"></i>
                        </span>
                        <div>
                          <p class="fw-semibold mb-1 text-dark">Téléphone</p>
                          <a :href="`tel:${checkinData.guest.phone}`" class="link-body-emphasis">
                            {{ checkinData.guest.phone }}
                          </a>
                        </div>
                      </li>
                      <li class="d-flex align-items-start gap-3 py-2">
                        <span class="icon-pill bg-secondary text-white">
                          <i class="fa-regular fa-envelope"></i>
                        </span>
                        <div>
                          <p class="fw-semibold mb-1 text-dark">Email</p>
                          <a :href="`mailto:${checkinData.guest.email}`" class="link-body-emphasis">
                            {{ checkinData.guest.email }}
                          </a>
                        </div>
                      </li>
                      <li class="d-flex align-items-start gap-3 py-2">
                        <span class="icon-pill bg-success text-white">
                          <i class="fa-regular fa-heart"></i>
                        </span>
                        <div>
                          <p class="fw-semibold mb-1 text-dark">Préférences</p>
                          <p class="mb-0 text-secondary">
                            {{ checkinData.guest.preferences }}
                          </p>
                        </div>
                      </li>
                    </ul>

                    <div class="bg-body-secondary-subtle rounded-4 p-4">
                      <p class="fw-semibold text-dark mb-2">
                        <i class="fa-regular fa-message me-2 text-primary"></i>Notes personnelles
                      </p>
                      <p class="mb-0 text-secondary">
                        {{ checkinData.guest.notes }}
                      </p>
                    </div>
                  </div>
                </article>
              </div>
            </div>
          </section>

          <section aria-labelledby="services-title" class="mb-5">
            <div class="card border-0 shadow-soft rounded-4 overflow-hidden">
              <div class="card-body p-4 p-lg-5">
                <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-4">
                  <div>
                    <h2 id="services-title" class="h4 fw-bold text-dark mb-1">
                      Services Pré-arrivée
                    </h2>
                    <p class="mb-0 text-secondary">
                      Anticipation des besoins pour un accueil chaleureux et fluide.
                    </p>
                  </div>
                  <span class="badge text-bg-success-subtle text-success-emphasis rounded-pill fw-semibold">
                    <i class="fa-solid fa-clipboard-check me-2"></i>{{ completedServices }}/{{ totalServices }} finalisés
                  </span>
                </div>

                <ul class="list-group list-group-flush services-list">
                  <li
                    v-for="service in checkinData.services"
                    :key="service.id"
                    class="list-group-item px-0 py-3 d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3"
                  >
                    <div class="d-flex align-items-start gap-3">
                      <span
                        class="icon-pill service-icon"
                        :class="service.completed ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary'"
                        aria-hidden="true"
                      >
                        <i
                          :class="[
                            'fa-regular',
                            service.completed ? 'fa-square-check' : 'fa-square'
                          ]"
                        ></i>
                      </span>
                      <div>
                        <p class="fw-semibold mb-1 text-dark">{{ service.title }}</p>
                        <p class="mb-1 text-secondary">{{ service.description }}</p>
                        <p class="mb-0 text-muted small">
                          <i class="fa-solid fa-user me-2 text-primary"></i>{{ service.assignedTo }}
                          <span v-if="service.deadline"> · {{ formatDate(service.deadline) }}</span>
                        </p>
                      </div>
                    </div>
                    <span
                      :class="[
                        'badge',
                        'rounded-pill',
                        service.completed ? 'text-bg-success-subtle text-success-emphasis' : 'text-bg-warning-subtle text-warning-emphasis'
                      ]"
                    >
                      {{ service.completed ? 'Terminé' : 'À suivre' }}
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section aria-labelledby="requests-title">
            <div class="card border-0 rounded-4 bg-light shadow-soft">
              <div class="card-body p-4 p-lg-5">
                <div class="d-flex align-items-start gap-3 mb-3">
                  <span class="icon-pill bg-primary text-white">
                    <i class="fa-solid fa-sparkles"></i>
                  </span>
                  <div>
                    <h2 id="requests-title" class="h4 fw-bold text-dark mb-1">
                      Demandes spécifiques
                    </h2>
                    <p class="text-secondary mb-0">
                      À préparer avant l'arrivée des invités.
                    </p>
                  </div>
                </div>
                <blockquote class="blockquote mb-0 text-secondary">
                  “{{ checkinData.specialRequests }}”
                </blockquote>
              </div>
            </div>
          </section>

          <footer class="mt-5 pt-4 border-top border-light">
            <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 text-secondary">
              <p class="mb-0">
                Besoin d’aide supplémentaire ? Contactez-nous 24/7 au
                <a :href="`tel:${checkinData.support.phone}`" class="link-underline-light fw-semibold">
                  {{ checkinData.support.phone }}
                </a>.
              </p>
              <a
                :href="checkinData.support.whatsapp"
                class="btn btn-outline-primary rounded-pill d-inline-flex align-items-center gap-2"
              >
                <i class="fa-brands fa-whatsapp"></i>
                Conversation WhatsApp
              </a>
            </div>
          </footer>
        </div>
      </div>
    </section>
  </main>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import axios, { AxiosResponse } from 'axios';

interface Collaborator {
  name: string;
  role: string;
  email: string;
  phone: string;
  highlight: string;
}

interface StayDetails {
  propertyName: string;
  address: string;
  startDate: string;
  endDate: string;
  arrivalWindow: string;
  departureTime: string;
  wifiNetwork: string;
  wifiPassword: string;
  keyInstructions: string;
  conciergeNotes: string;
}

interface GuestProfile {
  fullName: string;
  email: string;
  phone: string;
  country: string;
  occupants: number;
  vip: boolean;
  arrivalDetails: string;
  preferences: string;
  notes: string;
}

interface ServiceTask {
  id: number;
  title: string;
  description: string;
  completed: boolean;
  assignedTo: string;
  deadline?: string;
}

interface SupportInfo {
  phone: string;
  whatsapp: string;
}

interface CheckinResponse {
  id: number;
  status: string;
  collaborator: Collaborator;
  stay: StayDetails;
  guest: GuestProfile;
  services: ServiceTask[];
  specialRequests: string;
  support: SupportInfo;
}

const CHECKIN_ENDPOINT = '/api/checkin/123/';
const API_DELAY_MS = 1500;

const isLoading = ref(true);
const errorMessage = ref<string | null>(null);
const checkinData = ref<CheckinResponse | null>(null);

const mockApiData: CheckinResponse = {
  id: 123,
  status: 'Confirmé',
  collaborator: {
    name: 'Camille Dupont',
    role: 'Guest Experience Manager',
    email: 'camille.dupont@conciergerie-horizon.fr',
    phone: '+33 1 84 25 36 90',
    highlight: 'Briefing final confirmé pour 14h00'
  },
  stay: {
    propertyName: 'Appartement Louvre Étoile',
    address: '12 Rue de Rivoli, 75001 Paris',
    startDate: '2024-06-18',
    endDate: '2024-06-25',
    arrivalWindow: '15h00 – 17h00',
    departureTime: '11h00',
    wifiNetwork: 'LouvreStar',
    wifiPassword: 'Paris2024!',
    keyInstructions: 'Clés remises en main propre par le concierge à l’arrivée.',
    conciergeNotes: 'Prévoir une visite guidée rapide de l’appartement et présenter les équipements premium.'
  },
  guest: {
    fullName: 'Alexandra Moreau',
    email: 'alexandra.moreau@email.com',
    phone: '+1 (514) 555-0198',
    country: 'Canada',
    occupants: 4,
    vip: true,
    arrivalDetails: 'Vol AF348 · Arrivée 14h20 (CDG)',
    preferences: 'Champagne Laurent-Perrier rosé, eau minérale Vittel, fruits frais bio.',
    notes: 'Voyage en famille avec deux enfants (5 et 8 ans). Sensibilités aux parfums lourds.'
  },
  services: [
    {
      id: 1,
      title: 'Briefing housekeeping',
      description: 'Équipe housekeeping prévue le 17 juin à 10h00 pour préparation finale.',
      completed: true,
      assignedTo: 'Maëlle · Housekeeping Manager',
      deadline: '2024-06-17'
    },
    {
      id: 2,
      title: 'Panier de bienvenue & fleurs',
      description: 'Sélection de produits du marché bio + bouquet de pivoines roses.',
      completed: false,
      assignedTo: 'Lucie · Partenaire fleuriste',
      deadline: '2024-06-18'
    },
    {
      id: 3,
      title: 'Transfert aéroport premium',
      description: 'Chauffeur Tesla modèle X — plaque envoyée au client via WhatsApp.',
      completed: true,
      assignedTo: 'Alexis · Transport Privé',
      deadline: '2024-06-18'
    },
    {
      id: 4,
      title: 'Réservations restaurant',
      description: 'Table pour 4 au Septime le 20 juin à 19h30 (confirmée).',
      completed: true,
      assignedTo: 'Camille Dupont',
      deadline: '2024-06-16'
    }
  ],
  specialRequests:
    'Merci de préparer des fleurs fraîches dans le salon, des jeux de société pour enfants, et d’allumer la playlist lounge avant leur arrivée pour une ambiance douce.',
  support: {
    phone: '+33 7 81 45 62 30',
    whatsapp: 'https://wa.me/33781456230'
  }
};

const api = axios.create({
  adapter: async (config) => {
    await new Promise<void>((resolve) => setTimeout(resolve, API_DELAY_MS));
    return {
      data: mockApiData,
      status: 200,
      statusText: 'OK',
      headers: {},
      config,
      request: {}
    } as AxiosResponse<CheckinResponse>;
  }
});

onMounted(async () => {
  try {
    const response = await api.get<CheckinResponse>(CHECKIN_ENDPOINT);
    checkinData.value = response.data;
  } catch (error) {
    console.error(error);
    errorMessage.value =
      'Impossible de récupérer les détails du check-in pour le moment. Merci de réessayer dans quelques instants.';
  } finally {
    isLoading.value = false;
  }
});

const statusVariant = computed(() => {
  if (!checkinData.value) {
    return 'secondary';
  }
  const variants: Record<string, string> = {
    Confirmé: 'success',
    'En préparation': 'primary',
    'En attente': 'warning',
    Annulé: 'danger'
  };
  return variants[checkinData.value.status] ?? 'secondary';
});

const formattedStayDates = computed(() => {
  if (!checkinData.value) {
    return '';
  }
  const { startDate, endDate } = checkinData.value.stay;
  return `${formatDate(startDate)} – ${formatDate(endDate)}`;
});

const stayNights = computed(() => {
  if (!checkinData.value) {
    return 0;
  }
  const start = new Date(checkinData.value.stay.startDate).getTime();
  const end = new Date(checkinData.value.stay.endDate).getTime();
  return Math.max(1, Math.round((end - start) / (1000 * 60 * 60 * 24)));
});

const collaboratorInitials = computed(() => {
  if (!checkinData.value) {
    return '?';
  }
  const initials = checkinData.value.collaborator.name
    .split(' ')
    .filter(Boolean)
    .map((part) => part[0])
    .join('');
  return initials.slice(0, 2).toUpperCase();
});

const totalServices = computed(() => checkinData.value?.services.length ?? 0);
const completedServices = computed(
  () => checkinData.value?.services.filter((service) => service.completed).length ?? 0
);

function formatDate(isoDate: string): string {
  const formatter = new Intl.DateTimeFormat('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
  const formatted = formatter.format(new Date(isoDate));
  return formatted.charAt(0).toUpperCase() + formatted.slice(1);
}
</script>

<style scoped>
.checkin-page {
  min-height: 100vh;
}

.loading-section {
  min-height: 100vh;
  background: linear-gradient(135deg, rgba(13, 110, 253, 0.08), rgba(111, 66, 193, 0.08));
}

.spinner-lg {
  width: 4rem;
  height: 4rem;
}

.fade-in {
  animation: fadeIn 0.6s ease-out;
}

.status-badge {
  font-size: 1rem;
  padding: 0.75rem 1.5rem;
  border-radius: 999px;
}

.tracking-wide {
  letter-spacing: 0.12em;
}

.shadow-soft {
  box-shadow: 0 1.75rem 3.5rem rgba(15, 23, 42, 0.08);
}

.avatar-wrapper {
  width: 112px;
  height: 112px;
}

.avatar-fallback {
  width: 100%;
  height: 100%;
  border-radius: 2rem;
  background: linear-gradient(135deg, #5b8def, #a470f5);
  display: grid;
  place-items: center;
  color: #fff;
  font-size: 2.45rem;
  font-weight: 700;
  box-shadow: inset 0 0 0 4px rgba(255, 255, 255, 0.2), 0 12px 30px rgba(90, 66, 193, 0.25);
}

.collaborator-pill {
  background-color: rgba(13, 110, 253, 0.07);
  border-radius: 1.75rem;
  padding: 1rem 1.5rem;
}

.stay-badges .badge {
  font-size: 0.9rem;
  padding: 0.65rem 1.1rem;
  border-radius: 999px;
}

.icon-pill {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 3rem;
  height: 3rem;
  border-radius: 1.25rem;
  font-size: 1.25rem;
  flex-shrink: 0;
}

.icon-pill.service-icon {
  border-radius: 999px;
}

.info-chip {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.55rem 1.1rem;
  border-radius: 999px;
  background-color: rgba(13, 110, 253, 0.08);
  color: #1f2933;
  font-weight: 600;
  font-size: 0.95rem;
}

.services-list .list-group-item {
  border: none;
  border-bottom: 1px solid rgba(15, 23, 42, 0.07);
}

.services-list .list-group-item:last-child {
  border-bottom: none;
}

blockquote {
  font-size: 1.1rem;
  line-height: 1.7;
  position: relative;
  padding-left: 1.2rem;
}

blockquote::before {
  content: '“';
  font-size: 3rem;
  position: absolute;
  left: -0.1rem;
  top: -1.1rem;
  color: rgba(13, 110, 253, 0.25);
}

@media (max-width: 991.98px) {
  .display-5 {
    font-size: 2.5rem;
  }

  .collaborator-pill {
    width: 100%;
    text-align: left;
  }

  .status-badge {
    align-self: flex-start;
  }
}

@media (max-width: 575.98px) {
  .avatar-wrapper {
    width: 96px;
    height: 96px;
  }

  .icon-pill {
    width: 2.75rem;
    height: 2.75rem;
    font-size: 1.1rem;
  }

  .info-chip {
    width: 100%;
    justify-content: flex-start;
  }
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(18px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
